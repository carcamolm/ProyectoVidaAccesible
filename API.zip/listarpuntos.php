<?php
header('Content-Type: application/json');

if(isset($_POST['categoria']) && $_SERVER['REQUEST_METHOD']=='POST')
{
require_once 'conexion.php';
  // Extraer datos.
  

 

  // Sanitizar para hackers.
  $categoria = mysqli_real_escape_string($con, trim($_POST['categoria']));



  // insertar.
  $sql = "select * from punto where categoria like '%{$categoria}%'";
$datos=array();
    $res=$con->query($sql);
    while($campos=$res->fetch_object()){
        $datos[]=$campos;
        
    }
    echo json_encode($datos);
  
}