<?php
header('Content-Type: application/json');

if(isset($_POST['nombre']) && $_SERVER['REQUEST_METHOD']=='POST')
{
require_once 'conexion.php';
  // Extraer datos.
  

  // Validar.
  if(trim($_POST['nombre']) === '' || trim($_POST['categoria']) === '')
  {
    return http_response_code(400);
  }

  // Sanitizar para hackers.
  $nombre = mysqli_real_escape_string($con, trim($_POST['nombre']));
  $categoria = mysqli_real_escape_string($con, trim($_POST['categoria']));
  $latitud = mysqli_real_escape_string($con, trim($_POST['latitud']));
  $longitud = mysqli_real_escape_string($con, trim($_POST['longitud']));
$detalles = mysqli_real_escape_string($con, trim($_POST['detalles']));


  // insertar.
  $sql = "INSERT INTO punto VALUES (null,'{$nombre}','{$categoria}','{$latitud}','{$longitud}','{$detalles}')";

  if(mysqli_query($con,$sql))
  {
    http_response_code(201);
    echo json_encode(array("respuesta"=>"OK","mensaje"=>"Punto registrado correctamente"));
  }
  else
  {
    echo json_encode(array("respuesta"=>"Error","mensaje"=>"El punto ya se encuentra registrado".$sql));
  }
}