<?php

require_once 'conexion.php';
 
  // insertar.
  $sql = "select * from eventos order by id desc";

 

?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="padding:5px">

EVENTOS DE LA CIUDAD

    <?php
    $res=$con->query($sql);
    while($datos=$res->fetch_object()){
        ?>
        
       
            <strong><?php echo $datos->nombre;?></strong><br/>
            <i><?php echo $datos->institucion;?></i>
            <br/>Fecha:<?php echo strtoupper($datos->fecha);?>
        
        <hr/>
        <?php
    }
  
  ?>
  



</body>
</html>
