<?php
require_once 'conexion.php';
 if(trim(@$_POST['buscar'])==""){
  // insertar.
  $sql = "select DISTINCT(institucion) as nombre from eventos order by institucion";
 }else{
    $sql = "select institucion as nombre from eventos where institucion like '%{$_POST['buscar']}%' order by institucion";
 }

 

?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
<style>

</style>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body style="padding:5px">

Instituciones que realizan eventos<br/>
<form action="listarinstituciones.php" method="post">
<input  type="text" class="form-control" placeholder="Buscar institución" name="buscar"/> <br/> <input type="submit" class="btn-lg btn-block btn btn-info" value="Buscar"/>
<br/>
<a href=""  class="btn-lg btn-block btn btn-secondary">Limpiar busqueda</a>
<hr/>

</form>

<ul>
    <?php
    $res=$con->query($sql);
    while($datos=$res->fetch_object()){
        ?>
        
        <li>
            <strong><?php echo strtoupper($datos->nombre);?></strong><br/>
        </li>
        <hr/>
        <?php
    }
  
  ?>
  

</ul>

</body>
</html>
