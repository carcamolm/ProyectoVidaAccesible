<?php
header('Content-Type: application/json');

if(isset($_POST['nombre']) && $_SERVER['REQUEST_METHOD']=='POST')
{
require_once 'conexion.php';
  // Extraer datos.
  


  // Sanitizar para hackers.
  $nombre = mysqli_real_escape_string($con, trim($_POST['nombre']));
  $correo = mysqli_real_escape_string($con, trim($_POST['correo']));
  $desc = mysqli_real_escape_string($con, trim($_POST['descripcion']));


  // insertar.
  $sql = "INSERT INTO `experiencias`(`nombre`, `descripcion`, `correo_usuario`) VALUES ('{$nombre}','{$desc}','{$correo}')";

  if(mysqli_query($con,$sql))
  {
    http_response_code(201);
    echo json_encode(array("respuesta"=>"OK","mensaje"=>"Experiencia registrada correctamente"));
  }
  else
  {
    echo json_encode(array("respuesta"=>"Error","mensaje"=>"No se pudo registrar"));
  }
}