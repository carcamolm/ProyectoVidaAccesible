<?php
$con=new mysqli("localhost","afrodesc_vida","pwm3127383237","afrodesc_vida");
$con->set_charset("utf8");