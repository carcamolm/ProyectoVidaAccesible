<?php

require_once 'conexion.php';
 
  // insertar.
  $sql = "select * from elemento order by id desc";

 

?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

Seleccione el elemento para contactar al vendedor.

    <?php
    $res=$con->query($sql);
    while($datos=$res->fetch_object()){
        ?>
        
        
            <a href="https://api.whatsapp.com/send?phone=+57<?php echo $datos->telefono;?>&text=Quiero información sobre <?php echo strtoupper($datos->nombre);?>">
            <img src="<?php echo $datos->foto;?>" width="100%" height="30%"/><br/>
            <strong> <?php echo strtoupper($datos->nombre);?></strong><br/>
        Precio: $<?php echo number_format($datos->precio,0,",",".");?><br/>
         Teléfono: <?php echo $datos->telefono;?>
         </a>
        
        <hr/>
        <?php
    }
  
  ?>
  



</body>
</html>
