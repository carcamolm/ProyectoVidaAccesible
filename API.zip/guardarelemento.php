<?php
header('Content-Type: application/json');

if(isset($_POST['nombre']) && $_SERVER['REQUEST_METHOD']=='POST')
{
require_once 'conexion.php';
  // Extraer datos.
  

  // Validar.
 
$imagen=$_POST["imagen"];


  // Sanitizar para hackers.
  $nombre = mysqli_real_escape_string($con, trim($_POST['nombre']));
  $precio = mysqli_real_escape_string($con, trim($_POST['precio']));
  $tel = mysqli_real_escape_string($con, trim($_POST['telefono']));
  $nombrefoto = mysqli_real_escape_string($con, trim($_POST['nombrefoto']));
  $ruta="imagenes/$nombrefoto".date('dmyhis').rand(1,10000).".jpg";
  file_put_contents($ruta,base64_decode($imagen));

  // insertar.
   $sql = "INSERT INTO elemento VALUES (null,'{$nombre}','{$precio}','{$tel}','{$ruta}')";

  if(mysqli_query($con,$sql))
  {
    http_response_code(201);
    echo json_encode(array("respuesta"=>"OK","mensaje"=>"Elemento registrado correctamente"));
  }
  else
  {
    echo json_encode(array("respuesta"=>"Error","mensaje"=>"El elemento ya se encuentra registrado".$sql));
  }
}